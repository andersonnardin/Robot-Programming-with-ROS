
"use strict";

let Random = require('./Random.js')
let Position = require('./Position.js')

module.exports = {
  Random: Random,
  Position: Position,
};
