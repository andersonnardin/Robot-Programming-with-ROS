#include "ros/ros.h"
#include "robot_description/Random.h"


bool myrandom(robot_description::Random::Request &req, robot_description::Random::Response &res){
res.x = 1 + (rand() / ( RAND_MAX / (9-1) )) ;
res.y = 1 + (rand() / ( RAND_MAX / (9-1) )) ;
return true;
}




int main(int argc, char **argv)
{
ros::init(argc, argv, "random_server");
ros::NodeHandle n;
ros::ServiceServer service= n.advertiseService("/ran", myrandom);
ros::spin();

return 0;
}

