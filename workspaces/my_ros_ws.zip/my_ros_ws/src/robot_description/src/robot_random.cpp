#include "ros/ros.h"
#include "robot_description/Random.h"
#include "robot_description/Position.h"



int main (int argc, char **argv)
{
// Initialize the node, setup the NodeHandle for handling the communication with the ROS //system  
	ros::init(argc, argv, "robot_random");  
	ros::NodeHandle nh;
		
	ros::ServiceClient client3 = nh.serviceClient<robot_description::Random>("/ran");
	
	ros::ServiceClient client2 = nh.serviceClient<robot_description::Position>("/go_to_point");
	
	ros::Rate loop_rate(1);
	
	while (ros::ok()){
	
	robot_description::Random service_ran;
	robot_description::Position my_ran;
	
	client3.waitForExistence();
	client3.call(service_ran);
	my_ran.request.x = service_ran.response.x;
	my_ran.request.y = service_ran.response.y;
	my_ran.request.theta = 0;


	client2.waitForExistence();
	client2.call(my_ran);
	
	ROS_INFO("Turtle subscriber@[%f, %f, %f]",  my_ran.request.x, my_ran.request.y, my_ran.request.theta);
	
	ros::spinOnce();
     	loop_rate.sleep();
  	}
	
	return 0;
}


