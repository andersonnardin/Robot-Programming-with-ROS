#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Spawn.h"
#include "turtlesim/Kill.h"


float vlx;
float vaz;

void turtleCallback(const nav_msgs::Odometry::ConstPtr& msg)
	{
	ROS_INFO("Turtle velocity@[%f, %f]",  
	msg->twist.twist.linear.x, msg->twist.twist.angular.z);
	
	vlx = msg->twist.twist.linear.x;
	vaz = msg->twist.twist.angular.z;

}


int main (int argc, char **argv)
{
// Initialize the node, setup the NodeHandle for handling the communication with the ROS //system  
	ros::init(argc, argv, "copier");  
	ros::NodeHandle nh;
	
	ros::ServiceClient client2 = nh.serviceClient<turtlesim::Kill>("/kill");
	turtlesim::Kill srv2;
	srv2.request.name = "turtle1";
	client2.waitForExistence();
	client2.call(srv2);
	
	ros::ServiceClient client1 = nh.serviceClient<turtlesim::Spawn>("/spawn");
	turtlesim::Spawn srv1;
	srv1.request.x = 5.5;
	srv1.request.y = 5.5;
 	srv1.request.theta = 0.0;
 	srv1.request.name = "turtle2";
 	client1.waitForExistence();
	client1.call(srv1);
		
	ros::Publisher pub = nh.advertise<geometry_msgs::Twist> ("turtle2/cmd_vel", 1); 	
	ros::Subscriber sub = nh.subscribe("odom", 1,turtleCallback);
		
	ros::Rate loop_rate(1);
	
	while (ros::ok()){
	
	geometry_msgs::Twist my_vel;
	
	my_vel.linear.x = vlx;
	my_vel.angular.z = vaz;

	pub.publish(my_vel);
	
	ros::spinOnce();
     	loop_rate.sleep();
  	}
	
	return 0;
}


